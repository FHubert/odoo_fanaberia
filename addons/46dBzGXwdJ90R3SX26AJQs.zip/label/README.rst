==================
Label
==================

* This module will let you print particular product name, image and barcode 

* Label configuration menu will help you to configure label information and sizes 	

* Label print will help you to create label for particular products to make process less 

* Allow yout take image, name and barcode for many products.

Usage
=====
How to use it:

* Start server in terminal install module Label and click on the menu 'Label Configuration' and configure labels

* Click on the menu Label Print and give label name and select model and add fields 

* Open up the model which you have selected in Label print, click on the action you will see wizard to print 

* Select as per label configuration you can select brand and label size to print number of prints for single product.


Bug Tracker
===========

Credits
=======

Contributors
------------

* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>

